﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TopGolfManagementSystem.Models
{
    public class TrainingProgram
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string ProgramId { get; set; }

        public string ProgramName { get; set; }

        public decimal ProgramCost { get; set; }

        public int ProgramDuration { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string TrainerId { get; set; }
    }
}
