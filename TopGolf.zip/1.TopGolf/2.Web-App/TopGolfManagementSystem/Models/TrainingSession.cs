﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TopGolfManagementSystem.Models
{
    public class TrainingSession
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string SessionId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string TrainerId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string VenueId { get; set; }

        public string SessionDate { get; set; }

        public string SessionTime { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string PaymentId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string ProgramId { get; set; }
    }
}
