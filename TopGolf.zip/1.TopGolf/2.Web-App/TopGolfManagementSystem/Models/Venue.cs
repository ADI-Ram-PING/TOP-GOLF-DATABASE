﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TopGolfManagementSystem.Models
{
    public class Venue
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string VenueId { get; set; }

        public string VenueName { get; set; }

        public string VenueLocation { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string EmployeeId { get; set; }

        public string AssignedDate { get; set; }

        public string WorkArea { get; set; }
    }
}
