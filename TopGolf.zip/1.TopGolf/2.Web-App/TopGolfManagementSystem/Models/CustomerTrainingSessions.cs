﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TopGolfManagementSystem.Models
{
    public class CustomerTrainingSessions
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string CustomerTrainingSessionId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string CustomerId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string SessionId { get; set; }
    }
}

