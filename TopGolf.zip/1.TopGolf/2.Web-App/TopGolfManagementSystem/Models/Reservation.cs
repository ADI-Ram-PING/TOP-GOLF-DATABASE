﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TopGolfManagementSystem.Models
{
    public class Reservation
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string ReservationId { get; set; }

        public string ReservedTable { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string CustomerId { get; set; }

        public string ReservationTime { get; set; }

        public string ReservationDate { get; set; }

        public string Notes { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string SessionId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string PaymentId { get; set; }

        public decimal AmountPaid { get; set; }
    }
}
