﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TopGolfManagementSystem.Models
{
    public class Membership
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string MembershipId { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string CustomerId { get; set; }

        public string MembershipType { get; set; }

        public int MembershipDuration { get; set; }
    }
}
