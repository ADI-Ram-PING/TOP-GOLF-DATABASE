﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace TopGolfManagementSystem.Models
{
    public class Trainer
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string TrainerId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string PhoneNumber { get; set; }

        public string Availability { get; set; }
    }
}
