﻿using System.Collections.Generic;

namespace TopGolfManagementSystem.Models
{
    public class HomePageViewModel
    {
        public IEnumerable<Customer> Customers { get; set; }
        public IEnumerable<CustomerTrainingSessions> CustomerTrainingSessions { get; set; }
        public IEnumerable<Employee> Employees { get; set; }
        public IEnumerable<Trainer> Trainers { get; set; }
        public IEnumerable<TrainingProgram> TrainingPrograms { get; set; }
        public IEnumerable<TrainingSession> TrainingSessions { get; set; }
        public IEnumerable<Membership> Memberships { get; set; }
        public IEnumerable<Reservation> Reservations { get; set; }
        public IEnumerable<Venue> Venues { get; set; }
    }
}
