﻿using MongoDB.Driver;
using TopGolfManagementSystem.Models;

namespace TopGolfManagementSystem.Services
{
    public class MongoDBService
    {
        private readonly IMongoCollection<Customer> _customers;
        private readonly IMongoCollection<CustomerTrainingSessions> _customerTrainingSessions;
        private readonly IMongoCollection<Employee> _employees;
        private readonly IMongoCollection<Membership> _memberships;
        private readonly IMongoCollection<Reservation> _reservations;
        private readonly IMongoCollection<Trainer> _trainers;
        private readonly IMongoCollection<TrainingProgram> _trainingPrograms;
        private readonly IMongoCollection<TrainingSession> _trainingSessions;
        private readonly IMongoCollection<Venue> _venues;

        public MongoDBService(IConfiguration config)
        {
            var client = new MongoClient(config.GetValue<string>("MongoDB:ConnectionString"));
            var database = client.GetDatabase(config.GetValue<string>("MongoDB:DatabaseName"));

            _customers = database.GetCollection<Customer>("Customers");
            _customerTrainingSessions = database.GetCollection<CustomerTrainingSessions>("CustomerTrainingSessions");
            _employees = database.GetCollection<Employee>("Employees");
            _memberships = database.GetCollection<Membership>("Memberships");
            _reservations = database.GetCollection<Reservation>("Reservations");
            _trainers = database.GetCollection<Trainer>("Trainers");
            _trainingPrograms = database.GetCollection<TrainingProgram>("TrainingPrograms");
            _trainingSessions = database.GetCollection<TrainingSession>("TrainingSessions");
            _venues = database.GetCollection<Venue>("Venues");
        }

        // CRUD Operations for Customers
        public async Task<List<Customer>> GetCustomersAsync() =>
            await _customers.Find(customer => true).ToListAsync();

        public async Task CreateCustomerAsync(Customer customer) =>
            await _customers.InsertOneAsync(customer);

        public async Task UpdateCustomerAsync(string id, Customer updatedCustomer) =>
            await _customers.ReplaceOneAsync(customer => customer.CustomerId == id, updatedCustomer);

        public async Task DeleteCustomerAsync(string id) =>
            await _customers.DeleteOneAsync(customer => customer.CustomerId == id);

        // CRUD Operations for CustomerTrainingSessions
        public async Task<List<CustomerTrainingSessions>> GetCustomerTrainingSessionsAsync() =>
            await _customerTrainingSessions.Find(session => true).ToListAsync();

        public async Task CreateCustomerTrainingSessionAsync(CustomerTrainingSessions session) =>
            await _customerTrainingSessions.InsertOneAsync(session);

        public async Task UpdateCustomerTrainingSessionAsync(string id, CustomerTrainingSessions updatedSession) =>
            await _customerTrainingSessions.ReplaceOneAsync(session => session.CustomerTrainingSessionId == id, updatedSession);

        public async Task DeleteCustomerTrainingSessionAsync(string id) =>
            await _customerTrainingSessions.DeleteOneAsync(session => session.CustomerTrainingSessionId == id);

        // CRUD Operations for Employees
        public async Task<List<Employee>> GetEmployeesAsync() =>
            await _employees.Find(employee => true).ToListAsync();

        public async Task CreateEmployeeAsync(Employee employee) =>
            await _employees.InsertOneAsync(employee);

        public async Task UpdateEmployeeAsync(string id, Employee updatedEmployee) =>
            await _employees.ReplaceOneAsync(employee => employee.EmployeeId == id, updatedEmployee);

        public async Task DeleteEmployeeAsync(string id) =>
            await _employees.DeleteOneAsync(employee => employee.EmployeeId == id);

        // CRUD Operations for Memberships
        public async Task<List<Membership>> GetMembershipsAsync() =>
            await _memberships.Find(membership => true).ToListAsync();

        public async Task CreateMembershipAsync(Membership membership) =>
            await _memberships.InsertOneAsync(membership);

        public async Task UpdateMembershipAsync(string id, Membership updatedMembership) =>
            await _memberships.ReplaceOneAsync(membership => membership.MembershipId == id, updatedMembership);

        public async Task DeleteMembershipAsync(string id) =>
            await _memberships.DeleteOneAsync(membership => membership.MembershipId == id);

        // CRUD Operations for Reservations
        public async Task<List<Reservation>> GetReservationsAsync() =>
            await _reservations.Find(reservation => true).ToListAsync();

        public async Task CreateReservationAsync(Reservation reservation) =>
            await _reservations.InsertOneAsync(reservation);

        public async Task UpdateReservationAsync(string id, Reservation updatedReservation) =>
            await _reservations.ReplaceOneAsync(reservation => reservation.ReservationId == id, updatedReservation);

        public async Task DeleteReservationAsync(string id) =>
            await _reservations.DeleteOneAsync(reservation => reservation.ReservationId == id);

        // CRUD Operations for Trainers
        public async Task<List<Trainer>> GetTrainersAsync() =>
            await _trainers.Find(trainer => true).ToListAsync();

        public async Task CreateTrainerAsync(Trainer trainer) =>
            await _trainers.InsertOneAsync(trainer);

        public async Task UpdateTrainerAsync(string id, Trainer updatedTrainer) =>
            await _trainers.ReplaceOneAsync(trainer => trainer.TrainerId == id, updatedTrainer);

        public async Task DeleteTrainerAsync(string id) =>
            await _trainers.DeleteOneAsync(trainer => trainer.TrainerId == id);

        // CRUD Operations for TrainingPrograms
        public async Task<List<TrainingProgram>> GetTrainingProgramsAsync() =>
            await _trainingPrograms.Find(program => true).ToListAsync();

        public async Task CreateTrainingProgramAsync(TrainingProgram program) =>
            await _trainingPrograms.InsertOneAsync(program);

        public async Task UpdateTrainingProgramAsync(string id, TrainingProgram updatedProgram) =>
            await _trainingPrograms.ReplaceOneAsync(program => program.ProgramId == id, updatedProgram);

        public async Task DeleteTrainingProgramAsync(string id) =>
            await _trainingPrograms.DeleteOneAsync(program => program.ProgramId == id);

        // CRUD Operations for TrainingSessions
        public async Task<List<TrainingSession>> GetTrainingSessionsAsync() =>
            await _trainingSessions.Find(session => true).ToListAsync();

        public async Task CreateTrainingSessionAsync(TrainingSession session) =>
            await _trainingSessions.InsertOneAsync(session);

        public async Task UpdateTrainingSessionAsync(string id, TrainingSession updatedSession) =>
            await _trainingSessions.ReplaceOneAsync(session => session.SessionId == id, updatedSession);

        public async Task DeleteTrainingSessionAsync(string id) =>
            await _trainingSessions.DeleteOneAsync(session => session.SessionId == id);

        // CRUD Operations for Venues
        public async Task<List<Venue>> GetVenuesAsync() =>
            await _venues.Find(venue => true).ToListAsync();

        public async Task CreateVenueAsync(Venue venue) =>
            await _venues.InsertOneAsync(venue);

        public async Task UpdateVenueAsync(string id, Venue updatedVenue) =>
            await _venues.ReplaceOneAsync(venue => venue.VenueId == id, updatedVenue);

        public async Task DeleteVenueAsync(string id) =>
            await _venues.DeleteOneAsync(venue => venue.VenueId == id);
    }
}
