﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

namespace TopGolfManagementSystem.Controllers
{
    public class MembershipController : Controller
    {
        private readonly MongoDBService _mongoDBService;

        public MembershipController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        public async Task<IActionResult> Index()
        {
            var memberships = await _mongoDBService.GetMembershipsAsync();
            return View(memberships);
        }

        public async Task<IActionResult> CreateEdit(string? id)
        {
            ViewBag.Customers = new SelectList(await _mongoDBService.GetCustomersAsync(), "CustomerId", "FirstName");
            if (id == null)
                return View(new Membership());
            var membership = (await _mongoDBService.GetMembershipsAsync()).FirstOrDefault(m => m.MembershipId == id);
            return View(membership);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEdit(Membership membership)
        {
            if (string.IsNullOrEmpty(membership.MembershipId))
                await _mongoDBService.CreateMembershipAsync(membership);
            else
                await _mongoDBService.UpdateMembershipAsync(membership.MembershipId, membership);

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                await _mongoDBService.DeleteMembershipAsync(id);
            }
            return RedirectToAction("Index");
        }
    }
}
