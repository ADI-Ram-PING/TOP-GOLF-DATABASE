﻿using Microsoft.AspNetCore.Mvc;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

namespace TopGolfManagementSystem.Controllers
{
    public class VenueController : Controller
    {
        private readonly MongoDBService _mongoDBService;

        public VenueController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        public async Task<IActionResult> Index()
        {
            var venues = await _mongoDBService.GetVenuesAsync();
            return View(venues);
        }

        public async Task<IActionResult> CreateEdit(string? id)
        {
            if (id == null)
                return View(new Venue());
            var venue = (await _mongoDBService.GetVenuesAsync()).FirstOrDefault(v => v.VenueId == id);
            return View(venue);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEdit(Venue venue)
        {
            if (string.IsNullOrEmpty(venue.VenueId))
                await _mongoDBService.CreateVenueAsync(venue);
            else
                await _mongoDBService.UpdateVenueAsync(venue.VenueId, venue);

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                await _mongoDBService.DeleteVenueAsync(id);
            }
            return RedirectToAction("Index");
        }
    }
}
