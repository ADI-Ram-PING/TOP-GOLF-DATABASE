﻿using Microsoft.AspNetCore.Mvc;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

namespace TopGolfManagementSystem.Controllers
{
    public class TrainerController : Controller
    {
        private readonly MongoDBService _mongoDBService;

        public TrainerController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        public async Task<IActionResult> Index()
        {
            var trainers = await _mongoDBService.GetTrainersAsync();
            return View(trainers);
        }

        public async Task<IActionResult> CreateEdit(string? id)
        {
            if (id == null)
                return View(new Trainer());
            var trainer = (await _mongoDBService.GetTrainersAsync()).FirstOrDefault(t => t.TrainerId == id);
            return View(trainer);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEdit(Trainer trainer)
        {
            if (string.IsNullOrEmpty(trainer.TrainerId))
                await _mongoDBService.CreateTrainerAsync(trainer);
            else
                await _mongoDBService.UpdateTrainerAsync(trainer.TrainerId, trainer);

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                await _mongoDBService.DeleteTrainerAsync(id);
            }
            return RedirectToAction("Index");
        }
    }
}
