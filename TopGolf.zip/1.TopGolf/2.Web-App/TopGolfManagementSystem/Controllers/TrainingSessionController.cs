﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

namespace TopGolfManagementSystem.Controllers
{
    public class TrainingSessionController : Controller
    {
        private readonly MongoDBService _mongoDBService;

        public TrainingSessionController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        public async Task<IActionResult> Index()
        {
            var sessions = await _mongoDBService.GetTrainingSessionsAsync();
            return View(sessions);
        }

        public async Task<IActionResult> CreateEdit(string? id)
        {
            ViewBag.Programmes = new SelectList(await _mongoDBService.GetTrainingProgramsAsync(), "ProgramId", "ProgramName");
            if (id == null)
                return View(new TrainingSession());
            var session = (await _mongoDBService.GetTrainingSessionsAsync()).FirstOrDefault(s => s.SessionId == id);
            return View(session);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEdit(TrainingSession session)
        {
            if (string.IsNullOrEmpty(session.SessionId))
                await _mongoDBService.CreateTrainingSessionAsync(session);
            else
                await _mongoDBService.UpdateTrainingSessionAsync(session.SessionId, session);

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                await _mongoDBService.DeleteTrainingSessionAsync(id);
            }
            return RedirectToAction("Index");
        }
    }
}
