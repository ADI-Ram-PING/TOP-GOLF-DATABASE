﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

namespace TopGolfManagementSystem.Controllers
{
    public class ReservationController : Controller
    {
        private readonly MongoDBService _mongoDBService;

        public ReservationController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        public async Task<IActionResult> Index()
        {
            var reservations = await _mongoDBService.GetReservationsAsync();
            return View(reservations);
        }

        public async Task<IActionResult> CreateEdit(string? id)
        {
            ViewBag.Customers = new SelectList(await _mongoDBService.GetCustomersAsync(), "CustomerId", "FirstName");
            ViewBag.Sessions = new SelectList(await _mongoDBService.GetTrainingSessionsAsync(), "SessionId", "SessionDate");
            if (id == null)
                return View(new Reservation());
            var reservation = (await _mongoDBService.GetReservationsAsync()).FirstOrDefault(r => r.ReservationId == id);
            return View(reservation);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEdit(Reservation reservation)
        {
            if (string.IsNullOrEmpty(reservation.ReservationId))
                await _mongoDBService.CreateReservationAsync(reservation);
            else
                await _mongoDBService.UpdateReservationAsync(reservation.ReservationId, reservation);

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                await _mongoDBService.DeleteReservationAsync(id);
            }
            return RedirectToAction("Index");
        }
    }
}
