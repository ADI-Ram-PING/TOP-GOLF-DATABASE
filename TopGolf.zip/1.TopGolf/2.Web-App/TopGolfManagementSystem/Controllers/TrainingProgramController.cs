﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

namespace TopGolfManagementSystem.Controllers
{
    public class TrainingProgramController : Controller
    {
        private readonly MongoDBService _mongoDBService;

        public TrainingProgramController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        public async Task<IActionResult> Index()
        {
            var programs = await _mongoDBService.GetTrainingProgramsAsync();
            return View(programs);
        }

        public async Task<IActionResult> CreateEdit(string? id)
        {
            ViewBag.Trainers = new SelectList(await _mongoDBService.GetTrainersAsync(), "TrainerId", "FirstName");
            if (id == null)
                return View(new TrainingProgram());
            var program = (await _mongoDBService.GetTrainingProgramsAsync()).FirstOrDefault(p => p.ProgramId == id);
            return View(program);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEdit(TrainingProgram program)
        {
            if (string.IsNullOrEmpty(program.ProgramId))
                await _mongoDBService.CreateTrainingProgramAsync(program);
            else
                await _mongoDBService.UpdateTrainingProgramAsync(program.ProgramId, program);

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                await _mongoDBService.DeleteTrainingProgramAsync(id);
            }
            return RedirectToAction("Index");
        }
    }
}
