﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

namespace TopGolfManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly MongoDBService _mongoDBService;

        public HomeController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("IsLoggedIn") != "True")
            {
                return RedirectToAction("Index", "Login");
            }

            var customers = await _mongoDBService.GetCustomersAsync();
            var customerTrainingSessions = await _mongoDBService.GetCustomerTrainingSessionsAsync();
            var employees = await _mongoDBService.GetEmployeesAsync();
            var trainers = await _mongoDBService.GetTrainersAsync();
            var trainingPrograms = await _mongoDBService.GetTrainingProgramsAsync();
            var trainingSessions = await _mongoDBService.GetTrainingSessionsAsync();
            var memberships = await _mongoDBService.GetMembershipsAsync();
            var reservations = await _mongoDBService.GetReservationsAsync();
            var venues = await _mongoDBService.GetVenuesAsync();

            var model = new HomePageViewModel
            {
                Customers = customers,
                CustomerTrainingSessions = customerTrainingSessions,
                Employees = employees,
                Trainers = trainers,
                TrainingPrograms = trainingPrograms,
                TrainingSessions = trainingSessions,
                Memberships = memberships,
                Reservations = reservations,
                Venues = venues
            };

            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
