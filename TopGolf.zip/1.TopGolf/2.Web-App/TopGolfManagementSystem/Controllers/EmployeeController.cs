﻿using Microsoft.AspNetCore.Mvc;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

namespace TopGolfManagementSystem.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly MongoDBService _mongoDBService;

        public EmployeeController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        public async Task<IActionResult> Index()
        {
            var employees = await _mongoDBService.GetEmployeesAsync();
            return View(employees);
        }

        public async Task<IActionResult> CreateEdit(string? id)
        {
            if (id == null)
                return View(new Employee());
            var employee = (await _mongoDBService.GetEmployeesAsync()).FirstOrDefault(e => e.EmployeeId == id);
            return View(employee);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEdit(Employee employee)
        {
            var existingEmployeeWithEmail = (await _mongoDBService.GetEmployeesAsync()).FirstOrDefault(e => e.Email == employee.Email);
            if (existingEmployeeWithEmail != null && existingEmployeeWithEmail.EmployeeId != employee.EmployeeId)
            {
                ModelState.AddModelError("Email", "Email already exists.");
                return View(employee);
            }

            if (string.IsNullOrEmpty(employee.EmployeeId))
                await _mongoDBService.CreateEmployeeAsync(employee);
            else
                await _mongoDBService.UpdateEmployeeAsync(employee.EmployeeId, employee);

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                await _mongoDBService.DeleteEmployeeAsync(id);
            }
            return RedirectToAction("Index");
        }
    }
}
