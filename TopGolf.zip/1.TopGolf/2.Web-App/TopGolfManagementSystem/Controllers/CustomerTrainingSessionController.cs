﻿using Microsoft.AspNetCore.Mvc;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

namespace TopGolfManagementSystem.Controllers
{
    public class CustomerTrainingSessionsController : Controller
    {
        private readonly MongoDBService _mongoDBService;

        public CustomerTrainingSessionsController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        public async Task<IActionResult> Index()
        {
            var sessions = await _mongoDBService.GetCustomerTrainingSessionsAsync();
            return View(sessions);
        }

        public async Task<IActionResult> CreateEdit(string? id)
        {
            var customers = await _mongoDBService.GetCustomersAsync();
            var trainingSessions = await _mongoDBService.GetTrainingSessionsAsync();

            if (id == null)
            {
                ViewBag.Customers = customers.Any() ? customers : new List<Customer> { new Customer { CustomerId = "0", FirstName = "No Data" } };
                ViewBag.TrainingSessions = trainingSessions.Any() ? trainingSessions : new List<TrainingSession> { new TrainingSession { SessionId = "0", ProgramId = "No Data" } };

                return View(new CustomerTrainingSessions());
            }

            var session = (await _mongoDBService.GetCustomerTrainingSessionsAsync())
                          .FirstOrDefault(s => s.CustomerTrainingSessionId == id);

            if (session == null)
            {
                return NotFound("Training Session not found.");
            }

            ViewBag.Customers = customers.Any() ? customers : new List<Customer> { new Customer { CustomerId = "0", FirstName = "No Data" } };
            ViewBag.TrainingSessions = trainingSessions.Any() ? trainingSessions : new List<TrainingSession> { new TrainingSession { SessionId = "0", ProgramId = "No Data" } };

            return View(session);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEdit(CustomerTrainingSessions session)
        {
            if (session.CustomerId == "0" || session.SessionId == "0")
            {
                ModelState.AddModelError("", "Please select valid options for Customer and Training Session.");
                return View(session);
            }

            if (string.IsNullOrEmpty(session.CustomerTrainingSessionId))
            {
                await _mongoDBService.CreateCustomerTrainingSessionAsync(session);
            }
            else
            {
                await _mongoDBService.UpdateCustomerTrainingSessionAsync(session.CustomerTrainingSessionId, session);
            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                await _mongoDBService.DeleteCustomerTrainingSessionAsync(id);
            }
            return RedirectToAction("Index");
        }
    }
}
