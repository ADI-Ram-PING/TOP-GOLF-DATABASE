﻿using Microsoft.AspNetCore.Mvc;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

namespace TopGolfManagementSystem.Controllers
{
    public class CustomerController : Controller
    {
        private readonly MongoDBService _mongoDBService;

        public CustomerController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        public async Task<IActionResult> Index()
        {
            var customers = await _mongoDBService.GetCustomersAsync();
            return View(customers);
        }

        public async Task<IActionResult> CreateEdit(string? id)
        {
            if (id == null)
                return View(new Customer());
            var customer = (await _mongoDBService.GetCustomersAsync()).FirstOrDefault(c => c.CustomerId == id);
            return View(customer);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEdit(Customer customer)
        {
            var existingCustomerWithEmail = (await _mongoDBService.GetCustomersAsync()).FirstOrDefault(c => c.Email == customer.Email);

            if (existingCustomerWithEmail != null && existingCustomerWithEmail.CustomerId != customer.CustomerId)
            {
                ModelState.AddModelError("Email", "Email already exists.");
                return View(customer);
            }

            var existingCustomerWithName = (await _mongoDBService.GetCustomersAsync()).FirstOrDefault(c => c.FirstName == customer.FirstName && c.LastName == customer.LastName && c.Email != customer.Email);

            if (existingCustomerWithName != null)
            {
                ModelState.AddModelError("FirstName", "User already exists.");
                return View(customer);
            }

            if (string.IsNullOrEmpty(customer.CustomerId))
                await _mongoDBService.CreateCustomerAsync(customer);
            else
                await _mongoDBService.UpdateCustomerAsync(customer.CustomerId, customer);

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                await _mongoDBService.DeleteCustomerAsync(id);
            }
            return RedirectToAction("Index");
        }
    }
}

