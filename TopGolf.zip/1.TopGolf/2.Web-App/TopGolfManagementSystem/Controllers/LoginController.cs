﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

namespace TopGolfManagementSystem.Controllers
{
    public class LoginController : Controller
    {
        private readonly MongoDBService _mongoDBService;

        public LoginController(MongoDBService mongoDBService)
        {
            _mongoDBService = mongoDBService;
        }

        // GET: Login
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("IsLoggedIn") == "True")
            {
                return RedirectToAction("Index", "Home");
            }

            return View(); 
        }

        // POST: Login
        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            if (username == "Topgolf" && password == "Group 7")
            {
                HttpContext.Session.SetString("IsLoggedIn", "True");

                return RedirectToAction("Index", "Home");
            }

            ViewData["ErrorMessage"] = "Invalid username or password. Please try again.";
            return View("Index");
        }

        // Logout action
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Login");
        }
    }
}
