using Microsoft.Extensions.Options;
using TopGolfManagementSystem.Models;
using TopGolfManagementSystem.Services;

var builder = WebApplication.CreateBuilder(args);

// Register MongoDBService for dependency injection
builder.Services.AddSingleton<MongoDBService>();

// Add services to the container.
builder.Services.AddControllersWithViews();

// Add session or cookie-based authentication if necessary
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Set session timeout
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Add session middleware to check for login status
app.UseSession();

app.UseAuthorization();

// Protect Home and other pages by requiring login
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Login}/{action=Index}/{id?}");

app.Run();
