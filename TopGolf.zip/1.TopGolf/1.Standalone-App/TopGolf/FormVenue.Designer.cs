﻿namespace TopGolf
{
    partial class FormVenue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label venueIDLabel;
            System.Windows.Forms.Label venueNameLabel;
            System.Windows.Forms.Label venueLocationLabel;
            System.Windows.Forms.Label employeeIDLabel;
            System.Windows.Forms.Label assignedDateLabel;
            System.Windows.Forms.Label workAreaLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormVenue));
            this.customerTableAdapter = new TopGolf.TopGolfDataSetTableAdapters.CustomerTableAdapter();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.topGolfDataSet = new TopGolf.TopGolfDataSet();
            this.employeeTableAdapter = new TopGolf.TopGolfDataSetTableAdapters.EmployeeTableAdapter();
            this.BindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.tableAdapterManager = new TopGolf.TopGolfDataSetTableAdapters.TableAdapterManager();
            this.CustomerBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.RefreshButton = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.venueIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.venueNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.venueLocationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assignedDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workAreaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.venueBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Homebutton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.AddNewButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.venueIDTextBox = new System.Windows.Forms.TextBox();
            this.venueNameTextBox = new System.Windows.Forms.TextBox();
            this.venueLocationTextBox = new System.Windows.Forms.TextBox();
            this.employeeIDTextBox = new System.Windows.Forms.TextBox();
            this.assignedDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.workAreaTextBox = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.venueTableAdapter = new TopGolf.TopGolfDataSetTableAdapters.VenueTableAdapter();
            venueIDLabel = new System.Windows.Forms.Label();
            venueNameLabel = new System.Windows.Forms.Label();
            venueLocationLabel = new System.Windows.Forms.Label();
            employeeIDLabel = new System.Windows.Forms.Label();
            assignedDateLabel = new System.Windows.Forms.Label();
            workAreaLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.topGolfDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerBindingNavigator)).BeginInit();
            this.CustomerBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.venueBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // venueIDLabel
            // 
            venueIDLabel.AutoSize = true;
            venueIDLabel.Location = new System.Drawing.Point(6, 28);
            venueIDLabel.Name = "venueIDLabel";
            venueIDLabel.Size = new System.Drawing.Size(58, 15);
            venueIDLabel.TabIndex = 0;
            venueIDLabel.Text = "Venue ID:";
            // 
            // venueNameLabel
            // 
            venueNameLabel.AutoSize = true;
            venueNameLabel.Location = new System.Drawing.Point(6, 54);
            venueNameLabel.Name = "venueNameLabel";
            venueNameLabel.Size = new System.Drawing.Size(73, 15);
            venueNameLabel.TabIndex = 2;
            venueNameLabel.Text = "Venue Name:";
            // 
            // venueLocationLabel
            // 
            venueLocationLabel.AutoSize = true;
            venueLocationLabel.Location = new System.Drawing.Point(6, 80);
            venueLocationLabel.Name = "venueLocationLabel";
            venueLocationLabel.Size = new System.Drawing.Size(88, 15);
            venueLocationLabel.TabIndex = 4;
            venueLocationLabel.Text = "Venue Location:";
            // 
            // employeeIDLabel
            // 
            employeeIDLabel.AutoSize = true;
            employeeIDLabel.Location = new System.Drawing.Point(6, 106);
            employeeIDLabel.Name = "employeeIDLabel";
            employeeIDLabel.Size = new System.Drawing.Size(75, 15);
            employeeIDLabel.TabIndex = 6;
            employeeIDLabel.Text = "Employee ID:";
            // 
            // assignedDateLabel
            // 
            assignedDateLabel.AutoSize = true;
            assignedDateLabel.Location = new System.Drawing.Point(6, 133);
            assignedDateLabel.Name = "assignedDateLabel";
            assignedDateLabel.Size = new System.Drawing.Size(83, 15);
            assignedDateLabel.TabIndex = 8;
            assignedDateLabel.Text = "Assigned Date:";
            // 
            // workAreaLabel
            // 
            workAreaLabel.AutoSize = true;
            workAreaLabel.Location = new System.Drawing.Point(6, 158);
            workAreaLabel.Name = "workAreaLabel";
            workAreaLabel.Size = new System.Drawing.Size(67, 15);
            workAreaLabel.TabIndex = 10;
            workAreaLabel.Text = "Work Area:";
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.topGolfDataSet;
            // 
            // topGolfDataSet
            // 
            this.topGolfDataSet.DataSetName = "TopGolfDataSet";
            this.topGolfDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // BindingNavigatorSaveItem
            // 
            this.BindingNavigatorSaveItem.Name = "BindingNavigatorSaveItem";
            this.BindingNavigatorSaveItem.Size = new System.Drawing.Size(62, 22);
            this.BindingNavigatorSaveItem.Text = "Save Data";
            this.BindingNavigatorSaveItem.Click += new System.EventHandler(this.BindingNavigatorSaveItem_Click);
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Customer_TrainingSessionsTableAdapter = null;
            this.tableAdapterManager.CustomerTableAdapter = this.customerTableAdapter;
            this.tableAdapterManager.EmployeeTableAdapter = null;
            this.tableAdapterManager.MembershipTableAdapter = null;
            this.tableAdapterManager.ReservationsTableAdapter = null;
            this.tableAdapterManager.TrainerTableAdapter = null;
            this.tableAdapterManager.TrainingProgramTableAdapter = null;
            this.tableAdapterManager.TrainingSessionTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TopGolf.TopGolfDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VenueTableAdapter = null;
            // 
            // CustomerBindingNavigator
            // 
            this.CustomerBindingNavigator.AddNewItem = null;
            this.CustomerBindingNavigator.BindingSource = this.customerBindingSource;
            this.CustomerBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.CustomerBindingNavigator.DeleteItem = null;
            this.CustomerBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.BindingNavigatorSaveItem,
            this.RefreshButton});
            this.CustomerBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.CustomerBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.CustomerBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.CustomerBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.CustomerBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.CustomerBindingNavigator.Name = "CustomerBindingNavigator";
            this.CustomerBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.CustomerBindingNavigator.Size = new System.Drawing.Size(800, 25);
            this.CustomerBindingNavigator.TabIndex = 88;
            this.CustomerBindingNavigator.Text = "bindingNavigator1";
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            this.customerBindingSource.DataSource = this.topGolfDataSet;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(74, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(60, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Click += new System.EventHandler(this.bindingNavigatorDeleteItem_Click);
            // 
            // RefreshButton
            // 
            this.RefreshButton.Image = ((System.Drawing.Image)(resources.GetObject("RefreshButton.Image")));
            this.RefreshButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.RefreshButton.Name = "RefreshButton";
            this.RefreshButton.Size = new System.Drawing.Size(66, 22);
            this.RefreshButton.Text = "Refresh";
            this.RefreshButton.Click += new System.EventHandler(this.RefreshButton_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 360);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 22);
            this.statusStrip1.TabIndex = 87;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel1.Text = "Status";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.venueIDDataGridViewTextBoxColumn,
            this.venueNameDataGridViewTextBoxColumn,
            this.venueLocationDataGridViewTextBoxColumn,
            this.employeeIDDataGridViewTextBoxColumn,
            this.assignedDateDataGridViewTextBoxColumn,
            this.workAreaDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.venueBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(295, 44);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(493, 303);
            this.dataGridView1.TabIndex = 86;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // venueIDDataGridViewTextBoxColumn
            // 
            this.venueIDDataGridViewTextBoxColumn.DataPropertyName = "VenueID";
            this.venueIDDataGridViewTextBoxColumn.HeaderText = "VenueID";
            this.venueIDDataGridViewTextBoxColumn.Name = "venueIDDataGridViewTextBoxColumn";
            // 
            // venueNameDataGridViewTextBoxColumn
            // 
            this.venueNameDataGridViewTextBoxColumn.DataPropertyName = "VenueName";
            this.venueNameDataGridViewTextBoxColumn.HeaderText = "VenueName";
            this.venueNameDataGridViewTextBoxColumn.Name = "venueNameDataGridViewTextBoxColumn";
            // 
            // venueLocationDataGridViewTextBoxColumn
            // 
            this.venueLocationDataGridViewTextBoxColumn.DataPropertyName = "VenueLocation";
            this.venueLocationDataGridViewTextBoxColumn.HeaderText = "VenueLocation";
            this.venueLocationDataGridViewTextBoxColumn.Name = "venueLocationDataGridViewTextBoxColumn";
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            // 
            // assignedDateDataGridViewTextBoxColumn
            // 
            this.assignedDateDataGridViewTextBoxColumn.DataPropertyName = "AssignedDate";
            this.assignedDateDataGridViewTextBoxColumn.HeaderText = "AssignedDate";
            this.assignedDateDataGridViewTextBoxColumn.Name = "assignedDateDataGridViewTextBoxColumn";
            // 
            // workAreaDataGridViewTextBoxColumn
            // 
            this.workAreaDataGridViewTextBoxColumn.DataPropertyName = "WorkArea";
            this.workAreaDataGridViewTextBoxColumn.HeaderText = "WorkArea";
            this.workAreaDataGridViewTextBoxColumn.Name = "workAreaDataGridViewTextBoxColumn";
            // 
            // venueBindingSource
            // 
            this.venueBindingSource.DataMember = "Venue";
            this.venueBindingSource.DataSource = this.topGolfDataSet;
            // 
            // Homebutton
            // 
            this.Homebutton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Homebutton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Homebutton.Location = new System.Drawing.Point(140, 52);
            this.Homebutton.Name = "Homebutton";
            this.Homebutton.Size = new System.Drawing.Size(125, 29);
            this.Homebutton.TabIndex = 44;
            this.Homebutton.Text = "Go Home";
            this.Homebutton.UseVisualStyleBackColor = true;
            this.Homebutton.Click += new System.EventHandler(this.Homebutton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ExitButton.Location = new System.Drawing.Point(59, 87);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(125, 27);
            this.ExitButton.TabIndex = 43;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DeleteButton.Location = new System.Drawing.Point(9, 52);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(125, 27);
            this.DeleteButton.TabIndex = 42;
            this.DeleteButton.Text = "Delete Record";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // AddNewButton
            // 
            this.AddNewButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddNewButton.Location = new System.Drawing.Point(9, 19);
            this.AddNewButton.Name = "AddNewButton";
            this.AddNewButton.Size = new System.Drawing.Size(125, 27);
            this.AddNewButton.TabIndex = 38;
            this.AddNewButton.Text = "Add Record";
            this.AddNewButton.UseVisualStyleBackColor = true;
            this.AddNewButton.Click += new System.EventHandler(this.AddNewButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SaveButton.Location = new System.Drawing.Point(140, 19);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(125, 27);
            this.SaveButton.TabIndex = 39;
            this.SaveButton.Text = "Save Record";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(venueIDLabel);
            this.groupBox1.Controls.Add(this.venueIDTextBox);
            this.groupBox1.Controls.Add(venueNameLabel);
            this.groupBox1.Controls.Add(this.venueNameTextBox);
            this.groupBox1.Controls.Add(venueLocationLabel);
            this.groupBox1.Controls.Add(this.venueLocationTextBox);
            this.groupBox1.Controls.Add(employeeIDLabel);
            this.groupBox1.Controls.Add(this.employeeIDTextBox);
            this.groupBox1.Controls.Add(assignedDateLabel);
            this.groupBox1.Controls.Add(this.assignedDateDateTimePicker);
            this.groupBox1.Controls.Add(workAreaLabel);
            this.groupBox1.Controls.Add(this.workAreaTextBox);
            this.groupBox1.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(10, 44);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(279, 182);
            this.groupBox1.TabIndex = 84;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Info::";
            // 
            // venueIDTextBox
            // 
            this.venueIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.venueBindingSource, "VenueID", true));
            this.venueIDTextBox.Location = new System.Drawing.Point(97, 25);
            this.venueIDTextBox.Name = "venueIDTextBox";
            this.venueIDTextBox.Size = new System.Drawing.Size(174, 23);
            this.venueIDTextBox.TabIndex = 1;
            // 
            // venueNameTextBox
            // 
            this.venueNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.venueBindingSource, "VenueName", true));
            this.venueNameTextBox.Location = new System.Drawing.Point(97, 51);
            this.venueNameTextBox.Name = "venueNameTextBox";
            this.venueNameTextBox.Size = new System.Drawing.Size(174, 23);
            this.venueNameTextBox.TabIndex = 3;
            // 
            // venueLocationTextBox
            // 
            this.venueLocationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.venueBindingSource, "VenueLocation", true));
            this.venueLocationTextBox.Location = new System.Drawing.Point(97, 77);
            this.venueLocationTextBox.Name = "venueLocationTextBox";
            this.venueLocationTextBox.Size = new System.Drawing.Size(174, 23);
            this.venueLocationTextBox.TabIndex = 5;
            // 
            // employeeIDTextBox
            // 
            this.employeeIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.venueBindingSource, "EmployeeID", true));
            this.employeeIDTextBox.Location = new System.Drawing.Point(97, 103);
            this.employeeIDTextBox.Name = "employeeIDTextBox";
            this.employeeIDTextBox.Size = new System.Drawing.Size(174, 23);
            this.employeeIDTextBox.TabIndex = 7;
            // 
            // assignedDateDateTimePicker
            // 
            this.assignedDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.venueBindingSource, "AssignedDate", true));
            this.assignedDateDateTimePicker.Location = new System.Drawing.Point(97, 129);
            this.assignedDateDateTimePicker.Name = "assignedDateDateTimePicker";
            this.assignedDateDateTimePicker.Size = new System.Drawing.Size(174, 23);
            this.assignedDateDateTimePicker.TabIndex = 9;
            // 
            // workAreaTextBox
            // 
            this.workAreaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.venueBindingSource, "WorkArea", true));
            this.workAreaTextBox.Location = new System.Drawing.Point(97, 155);
            this.workAreaTextBox.Name = "workAreaTextBox";
            this.workAreaTextBox.Size = new System.Drawing.Size(174, 23);
            this.workAreaTextBox.TabIndex = 11;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Homebutton);
            this.groupBox2.Controls.Add(this.ExitButton);
            this.groupBox2.Controls.Add(this.DeleteButton);
            this.groupBox2.Controls.Add(this.SaveButton);
            this.groupBox2.Controls.Add(this.AddNewButton);
            this.groupBox2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(10, 232);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(279, 122);
            this.groupBox2.TabIndex = 85;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Commands::";
            // 
            // venueTableAdapter
            // 
            this.venueTableAdapter.ClearBeforeFill = true;
            // 
            // FormVenue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 382);
            this.Controls.Add(this.CustomerBindingNavigator);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "FormVenue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Venue";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormVenue_FormClosing);
            this.Load += new System.EventHandler(this.FormVenue_Load);
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.topGolfDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerBindingNavigator)).EndInit();
            this.CustomerBindingNavigator.ResumeLayout(false);
            this.CustomerBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.venueBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TopGolfDataSetTableAdapters.CustomerTableAdapter customerTableAdapter;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private TopGolfDataSet topGolfDataSet;
        private TopGolfDataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private System.Windows.Forms.ToolStripButton BindingNavigatorSaveItem;
        private TopGolfDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator CustomerBindingNavigator;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton RefreshButton;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Homebutton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Button AddNewButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.BindingSource venueBindingSource;
        private TopGolfDataSetTableAdapters.VenueTableAdapter venueTableAdapter;
        private System.Windows.Forms.TextBox venueIDTextBox;
        private System.Windows.Forms.TextBox venueNameTextBox;
        private System.Windows.Forms.TextBox venueLocationTextBox;
        private System.Windows.Forms.TextBox employeeIDTextBox;
        private System.Windows.Forms.DateTimePicker assignedDateDateTimePicker;
        private System.Windows.Forms.TextBox workAreaTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn venueIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn venueNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn venueLocationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn assignedDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn workAreaDataGridViewTextBoxColumn;
    }
}