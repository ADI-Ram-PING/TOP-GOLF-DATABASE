﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TopGolf
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            string msg = "Exit the application?";
            string caption = "Exit Application : TopGolf";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            MessageBoxIcon ico = MessageBoxIcon.Question;

            DialogResult result;

            result = MessageBox.Show(this, msg, caption, buttons, ico);
            if (result == DialogResult.Yes)
            {
                //closed the form.
                MessageBox.Show("Closed,", "Goodbye.",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                e.Cancel = false;

            }
            else
            {
                e.Cancel = true;
            }
        }

        private void Customerbutton_Click(object sender, EventArgs e)
        {
            FormCustomer fc = new FormCustomer();
            fc.Show();
            this.Hide();
        }

        private void Customer_TrainingSessionbutton_Click(object sender, EventArgs e)
        {
            FormCustomer_TrainingSessions ft = new FormCustomer_TrainingSessions();
            ft.Show();
            this.Hide();
        }

        private void Employeebutton_Click(object sender, EventArgs e)
        {
            FormEmployee fe = new FormEmployee();
            fe.Show();
            this.Hide();
        }

        private void Membershipbutton_Click(object sender, EventArgs e)
        {
            FormMembership fm = new FormMembership();
            fm.Show();
            this.Hide();
        }

        private void TrainingSessionbutton_Click(object sender, EventArgs e)
        {
            FormTrainingSession fs = new FormTrainingSession();
            fs.Show();
            this.Hide();
        }

        private void Trainerbutton_Click(object sender, EventArgs e)
        {
            FormTrainer fn = new FormTrainer();
            fn.Show();
            this.Hide();
        }

        private void TrainingProgrambutton_Click(object sender, EventArgs e)
        {
            FormTrainingProgram fp = new FormTrainingProgram();
            fp.Show();
            this.Hide();
        }

        private void Reservationsbutton_Click(object sender, EventArgs e)
        {
            FormReservations fr = new FormReservations();
            fr.Show();
            this.Hide();
        }

        private void Venuebutton_Click(object sender, EventArgs e)
        {
            FormVenue fv = new FormVenue();
            fv.Show();
            this.Hide();
        }

        private void Closebutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
