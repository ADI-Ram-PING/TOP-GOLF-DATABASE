﻿namespace TopGolf
{
    partial class FormTrainer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label trainerIDLabel;
            System.Windows.Forms.Label trainer_NameLabel;
            System.Windows.Forms.Label trainer_EmailLabel;
            System.Windows.Forms.Label trainer_PhoneNoLabel;
            System.Windows.Forms.Label trainer_AvailabilityLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTrainer));
            this.customerTableAdapter = new TopGolf.TopGolfDataSetTableAdapters.CustomerTableAdapter();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.topGolfDataSet = new TopGolf.TopGolfDataSet();
            this.employeeTableAdapter = new TopGolf.TopGolfDataSetTableAdapters.EmployeeTableAdapter();
            this.BindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.tableAdapterManager = new TopGolf.TopGolfDataSetTableAdapters.TableAdapterManager();
            this.CustomerBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.RefreshButton = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.trainerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainerNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainerEmailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainerPhoneNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainerAvailabilityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Homebutton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.AddNewButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.trainerIDTextBox = new System.Windows.Forms.TextBox();
            this.trainer_NameTextBox = new System.Windows.Forms.TextBox();
            this.trainer_EmailTextBox = new System.Windows.Forms.TextBox();
            this.trainer_PhoneNoTextBox = new System.Windows.Forms.TextBox();
            this.trainer_AvailabilityTextBox = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.trainerTableAdapter = new TopGolf.TopGolfDataSetTableAdapters.TrainerTableAdapter();
            trainerIDLabel = new System.Windows.Forms.Label();
            trainer_NameLabel = new System.Windows.Forms.Label();
            trainer_EmailLabel = new System.Windows.Forms.Label();
            trainer_PhoneNoLabel = new System.Windows.Forms.Label();
            trainer_AvailabilityLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.topGolfDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerBindingNavigator)).BeginInit();
            this.CustomerBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainerBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // trainerIDLabel
            // 
            trainerIDLabel.AutoSize = true;
            trainerIDLabel.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            trainerIDLabel.Location = new System.Drawing.Point(8, 23);
            trainerIDLabel.Name = "trainerIDLabel";
            trainerIDLabel.Size = new System.Drawing.Size(66, 15);
            trainerIDLabel.TabIndex = 0;
            trainerIDLabel.Text = "Trainer ID:";
            // 
            // trainer_NameLabel
            // 
            trainer_NameLabel.AutoSize = true;
            trainer_NameLabel.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            trainer_NameLabel.Location = new System.Drawing.Point(8, 49);
            trainer_NameLabel.Name = "trainer_NameLabel";
            trainer_NameLabel.Size = new System.Drawing.Size(81, 15);
            trainer_NameLabel.TabIndex = 2;
            trainer_NameLabel.Text = "Trainer Name:";
            // 
            // trainer_EmailLabel
            // 
            trainer_EmailLabel.AutoSize = true;
            trainer_EmailLabel.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            trainer_EmailLabel.Location = new System.Drawing.Point(8, 75);
            trainer_EmailLabel.Name = "trainer_EmailLabel";
            trainer_EmailLabel.Size = new System.Drawing.Size(80, 15);
            trainer_EmailLabel.TabIndex = 4;
            trainer_EmailLabel.Text = "Trainer Email:";
            // 
            // trainer_PhoneNoLabel
            // 
            trainer_PhoneNoLabel.AutoSize = true;
            trainer_PhoneNoLabel.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            trainer_PhoneNoLabel.Location = new System.Drawing.Point(8, 101);
            trainer_PhoneNoLabel.Name = "trainer_PhoneNoLabel";
            trainer_PhoneNoLabel.Size = new System.Drawing.Size(100, 15);
            trainer_PhoneNoLabel.TabIndex = 6;
            trainer_PhoneNoLabel.Text = "Trainer Phone No:";
            // 
            // trainer_AvailabilityLabel
            // 
            trainer_AvailabilityLabel.AutoSize = true;
            trainer_AvailabilityLabel.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            trainer_AvailabilityLabel.Location = new System.Drawing.Point(8, 127);
            trainer_AvailabilityLabel.Name = "trainer_AvailabilityLabel";
            trainer_AvailabilityLabel.Size = new System.Drawing.Size(112, 15);
            trainer_AvailabilityLabel.TabIndex = 8;
            trainer_AvailabilityLabel.Text = "Trainer Availability:";
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.topGolfDataSet;
            // 
            // topGolfDataSet
            // 
            this.topGolfDataSet.DataSetName = "TopGolfDataSet";
            this.topGolfDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // BindingNavigatorSaveItem
            // 
            this.BindingNavigatorSaveItem.Name = "BindingNavigatorSaveItem";
            this.BindingNavigatorSaveItem.Size = new System.Drawing.Size(62, 22);
            this.BindingNavigatorSaveItem.Text = "Save Data";
            this.BindingNavigatorSaveItem.Click += new System.EventHandler(this.BindingNavigatorSaveItem_Click);
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Customer_TrainingSessionsTableAdapter = null;
            this.tableAdapterManager.CustomerTableAdapter = this.customerTableAdapter;
            this.tableAdapterManager.EmployeeTableAdapter = null;
            this.tableAdapterManager.MembershipTableAdapter = null;
            this.tableAdapterManager.ReservationsTableAdapter = null;
            this.tableAdapterManager.TrainerTableAdapter = null;
            this.tableAdapterManager.TrainingProgramTableAdapter = null;
            this.tableAdapterManager.TrainingSessionTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TopGolf.TopGolfDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VenueTableAdapter = null;
            // 
            // CustomerBindingNavigator
            // 
            this.CustomerBindingNavigator.AddNewItem = null;
            this.CustomerBindingNavigator.BindingSource = this.customerBindingSource;
            this.CustomerBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.CustomerBindingNavigator.DeleteItem = null;
            this.CustomerBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.BindingNavigatorSaveItem,
            this.RefreshButton});
            this.CustomerBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.CustomerBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.CustomerBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.CustomerBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.CustomerBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.CustomerBindingNavigator.Name = "CustomerBindingNavigator";
            this.CustomerBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.CustomerBindingNavigator.Size = new System.Drawing.Size(839, 25);
            this.CustomerBindingNavigator.TabIndex = 88;
            this.CustomerBindingNavigator.Text = "bindingNavigator1";
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            this.customerBindingSource.DataSource = this.topGolfDataSet;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(74, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(60, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Click += new System.EventHandler(this.bindingNavigatorDeleteItem_Click);
            // 
            // RefreshButton
            // 
            this.RefreshButton.Image = ((System.Drawing.Image)(resources.GetObject("RefreshButton.Image")));
            this.RefreshButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.RefreshButton.Name = "RefreshButton";
            this.RefreshButton.Size = new System.Drawing.Size(66, 22);
            this.RefreshButton.Text = "Refresh";
            this.RefreshButton.Click += new System.EventHandler(this.RefreshButton_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 361);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(839, 22);
            this.statusStrip1.TabIndex = 87;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel1.Text = "Status";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.trainerIDDataGridViewTextBoxColumn,
            this.trainerNameDataGridViewTextBoxColumn,
            this.trainerEmailDataGridViewTextBoxColumn,
            this.trainerPhoneNoDataGridViewTextBoxColumn,
            this.trainerAvailabilityDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.trainerBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(295, 44);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(540, 303);
            this.dataGridView1.TabIndex = 86;
            // 
            // trainerIDDataGridViewTextBoxColumn
            // 
            this.trainerIDDataGridViewTextBoxColumn.DataPropertyName = "TrainerID";
            this.trainerIDDataGridViewTextBoxColumn.HeaderText = "TrainerID";
            this.trainerIDDataGridViewTextBoxColumn.Name = "trainerIDDataGridViewTextBoxColumn";
            // 
            // trainerNameDataGridViewTextBoxColumn
            // 
            this.trainerNameDataGridViewTextBoxColumn.DataPropertyName = "Trainer_Name";
            this.trainerNameDataGridViewTextBoxColumn.HeaderText = "Trainer_Name";
            this.trainerNameDataGridViewTextBoxColumn.Name = "trainerNameDataGridViewTextBoxColumn";
            // 
            // trainerEmailDataGridViewTextBoxColumn
            // 
            this.trainerEmailDataGridViewTextBoxColumn.DataPropertyName = "Trainer_Email";
            this.trainerEmailDataGridViewTextBoxColumn.HeaderText = "Trainer_Email";
            this.trainerEmailDataGridViewTextBoxColumn.Name = "trainerEmailDataGridViewTextBoxColumn";
            // 
            // trainerPhoneNoDataGridViewTextBoxColumn
            // 
            this.trainerPhoneNoDataGridViewTextBoxColumn.DataPropertyName = "Trainer_PhoneNo";
            this.trainerPhoneNoDataGridViewTextBoxColumn.HeaderText = "Trainer_PhoneNo";
            this.trainerPhoneNoDataGridViewTextBoxColumn.Name = "trainerPhoneNoDataGridViewTextBoxColumn";
            // 
            // trainerAvailabilityDataGridViewTextBoxColumn
            // 
            this.trainerAvailabilityDataGridViewTextBoxColumn.DataPropertyName = "Trainer_Availability";
            this.trainerAvailabilityDataGridViewTextBoxColumn.HeaderText = "Trainer_Availability";
            this.trainerAvailabilityDataGridViewTextBoxColumn.Name = "trainerAvailabilityDataGridViewTextBoxColumn";
            // 
            // trainerBindingSource
            // 
            this.trainerBindingSource.DataMember = "Trainer";
            this.trainerBindingSource.DataSource = this.topGolfDataSet;
            // 
            // Homebutton
            // 
            this.Homebutton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Homebutton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Homebutton.Location = new System.Drawing.Point(140, 52);
            this.Homebutton.Name = "Homebutton";
            this.Homebutton.Size = new System.Drawing.Size(125, 29);
            this.Homebutton.TabIndex = 44;
            this.Homebutton.Text = "Go Home";
            this.Homebutton.UseVisualStyleBackColor = true;
            this.Homebutton.Click += new System.EventHandler(this.Homebutton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ExitButton.Location = new System.Drawing.Point(59, 87);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(125, 27);
            this.ExitButton.TabIndex = 43;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DeleteButton.Location = new System.Drawing.Point(9, 52);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(125, 27);
            this.DeleteButton.TabIndex = 42;
            this.DeleteButton.Text = "Delete Record";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // AddNewButton
            // 
            this.AddNewButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddNewButton.Location = new System.Drawing.Point(9, 19);
            this.AddNewButton.Name = "AddNewButton";
            this.AddNewButton.Size = new System.Drawing.Size(125, 27);
            this.AddNewButton.TabIndex = 38;
            this.AddNewButton.Text = "Add Record";
            this.AddNewButton.UseVisualStyleBackColor = true;
            this.AddNewButton.Click += new System.EventHandler(this.AddNewButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SaveButton.Location = new System.Drawing.Point(140, 19);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(125, 27);
            this.SaveButton.TabIndex = 39;
            this.SaveButton.Text = "Save Record";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(trainerIDLabel);
            this.groupBox1.Controls.Add(this.trainerIDTextBox);
            this.groupBox1.Controls.Add(trainer_NameLabel);
            this.groupBox1.Controls.Add(this.trainer_NameTextBox);
            this.groupBox1.Controls.Add(trainer_EmailLabel);
            this.groupBox1.Controls.Add(this.trainer_EmailTextBox);
            this.groupBox1.Controls.Add(trainer_PhoneNoLabel);
            this.groupBox1.Controls.Add(this.trainer_PhoneNoTextBox);
            this.groupBox1.Controls.Add(trainer_AvailabilityLabel);
            this.groupBox1.Controls.Add(this.trainer_AvailabilityTextBox);
            this.groupBox1.Location = new System.Drawing.Point(12, 44);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(279, 175);
            this.groupBox1.TabIndex = 84;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Info::";
            // 
            // trainerIDTextBox
            // 
            this.trainerIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.trainerBindingSource, "TrainerID", true));
            this.trainerIDTextBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainerIDTextBox.Location = new System.Drawing.Point(109, 20);
            this.trainerIDTextBox.Name = "trainerIDTextBox";
            this.trainerIDTextBox.Size = new System.Drawing.Size(158, 23);
            this.trainerIDTextBox.TabIndex = 1;
            // 
            // trainer_NameTextBox
            // 
            this.trainer_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.trainerBindingSource, "Trainer_Name", true));
            this.trainer_NameTextBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainer_NameTextBox.Location = new System.Drawing.Point(109, 46);
            this.trainer_NameTextBox.Name = "trainer_NameTextBox";
            this.trainer_NameTextBox.Size = new System.Drawing.Size(158, 23);
            this.trainer_NameTextBox.TabIndex = 3;
            // 
            // trainer_EmailTextBox
            // 
            this.trainer_EmailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.trainerBindingSource, "Trainer_Email", true));
            this.trainer_EmailTextBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainer_EmailTextBox.Location = new System.Drawing.Point(109, 72);
            this.trainer_EmailTextBox.Name = "trainer_EmailTextBox";
            this.trainer_EmailTextBox.Size = new System.Drawing.Size(158, 23);
            this.trainer_EmailTextBox.TabIndex = 5;
            // 
            // trainer_PhoneNoTextBox
            // 
            this.trainer_PhoneNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.trainerBindingSource, "Trainer_PhoneNo", true));
            this.trainer_PhoneNoTextBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainer_PhoneNoTextBox.Location = new System.Drawing.Point(109, 98);
            this.trainer_PhoneNoTextBox.Name = "trainer_PhoneNoTextBox";
            this.trainer_PhoneNoTextBox.Size = new System.Drawing.Size(158, 23);
            this.trainer_PhoneNoTextBox.TabIndex = 7;
            // 
            // trainer_AvailabilityTextBox
            // 
            this.trainer_AvailabilityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.trainerBindingSource, "Trainer_Availability", true));
            this.trainer_AvailabilityTextBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainer_AvailabilityTextBox.Location = new System.Drawing.Point(126, 124);
            this.trainer_AvailabilityTextBox.Name = "trainer_AvailabilityTextBox";
            this.trainer_AvailabilityTextBox.Size = new System.Drawing.Size(141, 23);
            this.trainer_AvailabilityTextBox.TabIndex = 9;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Homebutton);
            this.groupBox2.Controls.Add(this.ExitButton);
            this.groupBox2.Controls.Add(this.DeleteButton);
            this.groupBox2.Controls.Add(this.SaveButton);
            this.groupBox2.Controls.Add(this.AddNewButton);
            this.groupBox2.Location = new System.Drawing.Point(14, 225);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(277, 122);
            this.groupBox2.TabIndex = 85;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Commands::";
            // 
            // trainerTableAdapter
            // 
            this.trainerTableAdapter.ClearBeforeFill = true;
            // 
            // FormTrainer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(839, 383);
            this.Controls.Add(this.CustomerBindingNavigator);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "FormTrainer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trainer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormTrainer_FormClosing);
            this.Load += new System.EventHandler(this.FormTrainer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.topGolfDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerBindingNavigator)).EndInit();
            this.CustomerBindingNavigator.ResumeLayout(false);
            this.CustomerBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainerBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TopGolfDataSetTableAdapters.CustomerTableAdapter customerTableAdapter;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private TopGolfDataSet topGolfDataSet;
        private TopGolfDataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private System.Windows.Forms.ToolStripButton BindingNavigatorSaveItem;
        private TopGolfDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator CustomerBindingNavigator;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton RefreshButton;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Homebutton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Button AddNewButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.BindingSource trainerBindingSource;
        private TopGolfDataSetTableAdapters.TrainerTableAdapter trainerTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainerNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainerEmailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainerPhoneNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainerAvailabilityDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox trainerIDTextBox;
        private System.Windows.Forms.TextBox trainer_NameTextBox;
        private System.Windows.Forms.TextBox trainer_EmailTextBox;
        private System.Windows.Forms.TextBox trainer_PhoneNoTextBox;
        private System.Windows.Forms.TextBox trainer_AvailabilityTextBox;
    }
}