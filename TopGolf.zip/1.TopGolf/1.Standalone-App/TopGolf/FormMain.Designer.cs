﻿namespace TopGolf
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Customerbutton = new System.Windows.Forms.Button();
            this.Customer_TrainingSessionbutton = new System.Windows.Forms.Button();
            this.Employeebutton = new System.Windows.Forms.Button();
            this.Membershipbutton = new System.Windows.Forms.Button();
            this.Reservationsbutton = new System.Windows.Forms.Button();
            this.Trainerbutton = new System.Windows.Forms.Button();
            this.TrainingProgrambutton = new System.Windows.Forms.Button();
            this.TrainingSessionbutton = new System.Windows.Forms.Button();
            this.Venuebutton = new System.Windows.Forms.Button();
            this.Closebutton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(103, 137);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(375, 34);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "Welcome to TopGolf Data Management";
            // 
            // Customerbutton
            // 
            this.Customerbutton.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Customerbutton.Location = new System.Drawing.Point(56, 180);
            this.Customerbutton.Name = "Customerbutton";
            this.Customerbutton.Size = new System.Drawing.Size(111, 42);
            this.Customerbutton.TabIndex = 1;
            this.Customerbutton.Text = "Customer";
            this.Customerbutton.UseVisualStyleBackColor = true;
            this.Customerbutton.Click += new System.EventHandler(this.Customerbutton_Click);
            // 
            // Customer_TrainingSessionbutton
            // 
            this.Customer_TrainingSessionbutton.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Customer_TrainingSessionbutton.Location = new System.Drawing.Point(194, 184);
            this.Customer_TrainingSessionbutton.Name = "Customer_TrainingSessionbutton";
            this.Customer_TrainingSessionbutton.Size = new System.Drawing.Size(193, 38);
            this.Customer_TrainingSessionbutton.TabIndex = 2;
            this.Customer_TrainingSessionbutton.Text = "Customer_Training Sessions";
            this.Customer_TrainingSessionbutton.UseVisualStyleBackColor = true;
            this.Customer_TrainingSessionbutton.Click += new System.EventHandler(this.Customer_TrainingSessionbutton_Click);
            // 
            // Employeebutton
            // 
            this.Employeebutton.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Employeebutton.Location = new System.Drawing.Point(417, 184);
            this.Employeebutton.Name = "Employeebutton";
            this.Employeebutton.Size = new System.Drawing.Size(114, 47);
            this.Employeebutton.TabIndex = 3;
            this.Employeebutton.Text = "Employee";
            this.Employeebutton.UseVisualStyleBackColor = true;
            this.Employeebutton.Click += new System.EventHandler(this.Employeebutton_Click);
            // 
            // Membershipbutton
            // 
            this.Membershipbutton.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Membershipbutton.Location = new System.Drawing.Point(56, 235);
            this.Membershipbutton.Name = "Membershipbutton";
            this.Membershipbutton.Size = new System.Drawing.Size(111, 44);
            this.Membershipbutton.TabIndex = 4;
            this.Membershipbutton.Text = "Membership";
            this.Membershipbutton.UseVisualStyleBackColor = true;
            this.Membershipbutton.Click += new System.EventHandler(this.Membershipbutton_Click);
            // 
            // Reservationsbutton
            // 
            this.Reservationsbutton.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reservationsbutton.Location = new System.Drawing.Point(224, 294);
            this.Reservationsbutton.Name = "Reservationsbutton";
            this.Reservationsbutton.Size = new System.Drawing.Size(122, 44);
            this.Reservationsbutton.TabIndex = 5;
            this.Reservationsbutton.Text = "Reservations";
            this.Reservationsbutton.UseVisualStyleBackColor = true;
            this.Reservationsbutton.Click += new System.EventHandler(this.Reservationsbutton_Click);
            // 
            // Trainerbutton
            // 
            this.Trainerbutton.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Trainerbutton.Location = new System.Drawing.Point(417, 237);
            this.Trainerbutton.Name = "Trainerbutton";
            this.Trainerbutton.Size = new System.Drawing.Size(114, 42);
            this.Trainerbutton.TabIndex = 6;
            this.Trainerbutton.Text = "Trainer";
            this.Trainerbutton.UseVisualStyleBackColor = true;
            this.Trainerbutton.Click += new System.EventHandler(this.Trainerbutton_Click);
            // 
            // TrainingProgrambutton
            // 
            this.TrainingProgrambutton.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrainingProgrambutton.Location = new System.Drawing.Point(56, 291);
            this.TrainingProgrambutton.Name = "TrainingProgrambutton";
            this.TrainingProgrambutton.Size = new System.Drawing.Size(111, 47);
            this.TrainingProgrambutton.TabIndex = 7;
            this.TrainingProgrambutton.Text = "Training Program";
            this.TrainingProgrambutton.UseVisualStyleBackColor = true;
            this.TrainingProgrambutton.Click += new System.EventHandler(this.TrainingProgrambutton_Click);
            // 
            // TrainingSessionbutton
            // 
            this.TrainingSessionbutton.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrainingSessionbutton.Location = new System.Drawing.Point(212, 235);
            this.TrainingSessionbutton.Name = "TrainingSessionbutton";
            this.TrainingSessionbutton.Size = new System.Drawing.Size(146, 44);
            this.TrainingSessionbutton.TabIndex = 8;
            this.TrainingSessionbutton.Text = "TrainingSession";
            this.TrainingSessionbutton.UseVisualStyleBackColor = true;
            this.TrainingSessionbutton.Click += new System.EventHandler(this.TrainingSessionbutton_Click);
            // 
            // Venuebutton
            // 
            this.Venuebutton.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Venuebutton.Location = new System.Drawing.Point(417, 293);
            this.Venuebutton.Name = "Venuebutton";
            this.Venuebutton.Size = new System.Drawing.Size(111, 43);
            this.Venuebutton.TabIndex = 9;
            this.Venuebutton.Text = "Venue";
            this.Venuebutton.UseVisualStyleBackColor = true;
            this.Venuebutton.Click += new System.EventHandler(this.Venuebutton_Click);
            // 
            // Closebutton
            // 
            this.Closebutton.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Closebutton.Location = new System.Drawing.Point(212, 360);
            this.Closebutton.Name = "Closebutton";
            this.Closebutton.Size = new System.Drawing.Size(166, 40);
            this.Closebutton.TabIndex = 10;
            this.Closebutton.Text = "Close Application";
            this.Closebutton.UseVisualStyleBackColor = true;
            this.Closebutton.Click += new System.EventHandler(this.Closebutton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TopGolf.Properties.Resources.images;
            this.pictureBox1.Location = new System.Drawing.Point(137, 1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(287, 129);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 424);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Closebutton);
            this.Controls.Add(this.Venuebutton);
            this.Controls.Add(this.TrainingSessionbutton);
            this.Controls.Add(this.TrainingProgrambutton);
            this.Controls.Add(this.Trainerbutton);
            this.Controls.Add(this.Reservationsbutton);
            this.Controls.Add(this.Membershipbutton);
            this.Controls.Add(this.Employeebutton);
            this.Controls.Add(this.Customer_TrainingSessionbutton);
            this.Controls.Add(this.Customerbutton);
            this.Controls.Add(this.textBox1);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Customerbutton;
        private System.Windows.Forms.Button Customer_TrainingSessionbutton;
        private System.Windows.Forms.Button Employeebutton;
        private System.Windows.Forms.Button Membershipbutton;
        private System.Windows.Forms.Button Reservationsbutton;
        private System.Windows.Forms.Button Trainerbutton;
        private System.Windows.Forms.Button TrainingProgrambutton;
        private System.Windows.Forms.Button TrainingSessionbutton;
        private System.Windows.Forms.Button Venuebutton;
        private System.Windows.Forms.Button Closebutton;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}