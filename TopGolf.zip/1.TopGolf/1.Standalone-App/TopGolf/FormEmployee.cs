﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TopGolf
{
    public partial class FormEmployee : Form
    {
        public FormEmployee()
        {
            InitializeComponent();
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            AddNewButton.PerformClick();
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            DeleteButton.PerformClick();
        }

        private void BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            SaveButton.PerformClick();
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            RefreshButton.PerformClick();
        }

        private void FormEmployee_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'topGolfDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.topGolfDataSet.Employee);

        }

        private void AddNewButton_Click(object sender, EventArgs e)
        {
            try
            {
                string msg = "Add New Record?";
                string caption = "Add New";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                MessageBoxIcon icon = MessageBoxIcon.Question;

                DialogResult result;

                result = MessageBox.Show(this, msg, caption, buttons, icon);

                if (result == DialogResult.Yes)
                {
                    //Add new record
                    this.employeeBindingSource.AddNew();

                    //save| update
                    this.employeeBindingSource.EndEdit();
                    this.employeeTableAdapter.Update(this.topGolfDataSet.Employee);

                    //refresh records
                    this.employeeTableAdapter.Fill(this.topGolfDataSet.Employee);

                    MessageBox.Show("Data Added Success", "Add Data",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Add Data Failed" + ex.Message.ToString(), "Add Data",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                string msg = "Save the Record?";
                string caption = "Save | Update";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                MessageBoxIcon icon = MessageBoxIcon.Question;

                DialogResult result;

                result = MessageBox.Show(this, msg, caption, buttons, icon);

                if (result == DialogResult.Yes)
                {
                    //save| update
                    this.employeeBindingSource.EndEdit();
                    this.employeeTableAdapter.Update(this.topGolfDataSet.Employee);

                    //refresh records
                    this.employeeTableAdapter.Fill(this.topGolfDataSet.Employee);

                    MessageBox.Show("Data Saved Success", "Save Data",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Save | Update Data Failed" + ex.Message.ToString(), "Save Data",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                string msg = "Delete Selected Record?";
                string caption = "Delete Data";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                MessageBoxIcon icon = MessageBoxIcon.Question;

                DialogResult result;

                result = MessageBox.Show(this, msg, caption, buttons, icon);

                if (result == DialogResult.Yes)
                {
                    //Delete
                    this.employeeBindingSource.RemoveCurrent();

                    //Save the changes
                    this.employeeBindingSource.EndEdit();
                    this.employeeTableAdapter.Update(this.topGolfDataSet.Employee);

                    //refresh records
                    this.employeeTableAdapter.Fill(this.topGolfDataSet.Employee);

                    MessageBox.Show("Data Deleted Successfully", "Delete Data",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete Data Failed" + ex.Message.ToString(), "Delete Data",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Homebutton_Click(object sender, EventArgs e)
        {
            FormMain fe = new FormMain();
            fe.Show();
            this.Hide();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bindingNavigatorDeleteItem_Click_1(object sender, EventArgs e)
        {
            DeleteButton.PerformClick();
        }

        private void BindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            SaveButton.PerformClick();
        }

        private void RefreshButton_Click_1(object sender, EventArgs e)
        {
            RefreshButton.PerformClick();
        }

        private void FormEmployee_FormClosing(object sender, FormClosingEventArgs e)
        {
            string msg = "Exit the application?";
            string caption = "Exit Application : TopGolf";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            MessageBoxIcon ico = MessageBoxIcon.Question;

            DialogResult result;

            result = MessageBox.Show(this, msg, caption, buttons, ico);
            if (result == DialogResult.Yes)
            {
                //closed the form.
                MessageBox.Show("Closed,", "Goodbye.",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                e.Cancel = false;

            }
            else
            {
                e.Cancel = true;
            }
        }
    }
}
