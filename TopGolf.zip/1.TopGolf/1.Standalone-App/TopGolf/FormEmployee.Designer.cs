﻿namespace TopGolf
{
    partial class FormEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label employeeIDLabel;
            System.Windows.Forms.Label emp_FirstNameLabel;
            System.Windows.Forms.Label emp_LastNameLabel;
            System.Windows.Forms.Label emp_EmailLabel;
            System.Windows.Forms.Label emp_PhoneNoLabel;
            System.Windows.Forms.Label emp_RoleLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEmployee));
            this.BindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.Homebutton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.AddNewButton = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.CustomerBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.topGolfDataSet = new TopGolf.TopGolfDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.RefreshButton = new System.Windows.Forms.ToolStripButton();
            this.SaveButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empFirstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empLastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empEmailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empPhoneNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empRoleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.employeeIDTextBox = new System.Windows.Forms.TextBox();
            this.emp_FirstNameTextBox = new System.Windows.Forms.TextBox();
            this.emp_LastNameTextBox = new System.Windows.Forms.TextBox();
            this.emp_EmailTextBox = new System.Windows.Forms.TextBox();
            this.emp_PhoneNoTextBox = new System.Windows.Forms.TextBox();
            this.emp_RoleTextBox = new System.Windows.Forms.TextBox();
            this.customerTableAdapter = new TopGolf.TopGolfDataSetTableAdapters.CustomerTableAdapter();
            this.tableAdapterManager = new TopGolf.TopGolfDataSetTableAdapters.TableAdapterManager();
            this.employeeTableAdapter = new TopGolf.TopGolfDataSetTableAdapters.EmployeeTableAdapter();
            employeeIDLabel = new System.Windows.Forms.Label();
            emp_FirstNameLabel = new System.Windows.Forms.Label();
            emp_LastNameLabel = new System.Windows.Forms.Label();
            emp_EmailLabel = new System.Windows.Forms.Label();
            emp_PhoneNoLabel = new System.Windows.Forms.Label();
            emp_RoleLabel = new System.Windows.Forms.Label();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerBindingNavigator)).BeginInit();
            this.CustomerBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.topGolfDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // employeeIDLabel
            // 
            employeeIDLabel.AutoSize = true;
            employeeIDLabel.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            employeeIDLabel.Location = new System.Drawing.Point(6, 19);
            employeeIDLabel.Name = "employeeIDLabel";
            employeeIDLabel.Size = new System.Drawing.Size(75, 15);
            employeeIDLabel.TabIndex = 0;
            employeeIDLabel.Text = "Employee ID:";
            // 
            // emp_FirstNameLabel
            // 
            emp_FirstNameLabel.AutoSize = true;
            emp_FirstNameLabel.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            emp_FirstNameLabel.Location = new System.Drawing.Point(6, 45);
            emp_FirstNameLabel.Name = "emp_FirstNameLabel";
            emp_FirstNameLabel.Size = new System.Drawing.Size(90, 15);
            emp_FirstNameLabel.TabIndex = 2;
            emp_FirstNameLabel.Text = "Emp First Name:";
            // 
            // emp_LastNameLabel
            // 
            emp_LastNameLabel.AutoSize = true;
            emp_LastNameLabel.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            emp_LastNameLabel.Location = new System.Drawing.Point(6, 71);
            emp_LastNameLabel.Name = "emp_LastNameLabel";
            emp_LastNameLabel.Size = new System.Drawing.Size(87, 15);
            emp_LastNameLabel.TabIndex = 4;
            emp_LastNameLabel.Text = "Emp Last Name:";
            // 
            // emp_EmailLabel
            // 
            emp_EmailLabel.AutoSize = true;
            emp_EmailLabel.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            emp_EmailLabel.Location = new System.Drawing.Point(6, 97);
            emp_EmailLabel.Name = "emp_EmailLabel";
            emp_EmailLabel.Size = new System.Drawing.Size(62, 15);
            emp_EmailLabel.TabIndex = 6;
            emp_EmailLabel.Text = "Emp Email:";
            // 
            // emp_PhoneNoLabel
            // 
            emp_PhoneNoLabel.AutoSize = true;
            emp_PhoneNoLabel.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            emp_PhoneNoLabel.Location = new System.Drawing.Point(6, 123);
            emp_PhoneNoLabel.Name = "emp_PhoneNoLabel";
            emp_PhoneNoLabel.Size = new System.Drawing.Size(82, 15);
            emp_PhoneNoLabel.TabIndex = 8;
            emp_PhoneNoLabel.Text = "Emp Phone No:";
            // 
            // emp_RoleLabel
            // 
            emp_RoleLabel.AutoSize = true;
            emp_RoleLabel.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            emp_RoleLabel.Location = new System.Drawing.Point(6, 149);
            emp_RoleLabel.Name = "emp_RoleLabel";
            emp_RoleLabel.Size = new System.Drawing.Size(56, 15);
            emp_RoleLabel.TabIndex = 10;
            emp_RoleLabel.Text = "Emp Role:";
            // 
            // BindingNavigatorSaveItem
            // 
            this.BindingNavigatorSaveItem.Name = "BindingNavigatorSaveItem";
            this.BindingNavigatorSaveItem.Size = new System.Drawing.Size(62, 22);
            this.BindingNavigatorSaveItem.Text = "Save Data";
            this.BindingNavigatorSaveItem.Click += new System.EventHandler(this.BindingNavigatorSaveItem_Click_1);
            // 
            // Homebutton
            // 
            this.Homebutton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Homebutton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Homebutton.Location = new System.Drawing.Point(140, 52);
            this.Homebutton.Name = "Homebutton";
            this.Homebutton.Size = new System.Drawing.Size(125, 29);
            this.Homebutton.TabIndex = 44;
            this.Homebutton.Text = "Go Home";
            this.Homebutton.UseVisualStyleBackColor = true;
            this.Homebutton.Click += new System.EventHandler(this.Homebutton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ExitButton.Location = new System.Drawing.Point(59, 87);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(125, 27);
            this.ExitButton.TabIndex = 43;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DeleteButton.Location = new System.Drawing.Point(9, 52);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(125, 27);
            this.DeleteButton.TabIndex = 42;
            this.DeleteButton.Text = "Delete Record";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // AddNewButton
            // 
            this.AddNewButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddNewButton.Location = new System.Drawing.Point(9, 19);
            this.AddNewButton.Name = "AddNewButton";
            this.AddNewButton.Size = new System.Drawing.Size(125, 27);
            this.AddNewButton.TabIndex = 38;
            this.AddNewButton.Text = "Add Record";
            this.AddNewButton.UseVisualStyleBackColor = true;
            this.AddNewButton.Click += new System.EventHandler(this.AddNewButton_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 369);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(855, 22);
            this.statusStrip1.TabIndex = 82;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel1.Text = "Status";
            // 
            // CustomerBindingNavigator
            // 
            this.CustomerBindingNavigator.AddNewItem = null;
            this.CustomerBindingNavigator.BindingSource = this.customerBindingSource;
            this.CustomerBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.CustomerBindingNavigator.DeleteItem = null;
            this.CustomerBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.BindingNavigatorSaveItem,
            this.RefreshButton});
            this.CustomerBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.CustomerBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.CustomerBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.CustomerBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.CustomerBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.CustomerBindingNavigator.Name = "CustomerBindingNavigator";
            this.CustomerBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.CustomerBindingNavigator.Size = new System.Drawing.Size(855, 25);
            this.CustomerBindingNavigator.TabIndex = 83;
            this.CustomerBindingNavigator.Text = "bindingNavigator1";
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            this.customerBindingSource.DataSource = this.topGolfDataSet;
            // 
            // topGolfDataSet
            // 
            this.topGolfDataSet.DataSetName = "TopGolfDataSet";
            this.topGolfDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(74, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(60, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Click += new System.EventHandler(this.bindingNavigatorDeleteItem_Click_1);
            // 
            // RefreshButton
            // 
            this.RefreshButton.Image = ((System.Drawing.Image)(resources.GetObject("RefreshButton.Image")));
            this.RefreshButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.RefreshButton.Name = "RefreshButton";
            this.RefreshButton.Size = new System.Drawing.Size(66, 22);
            this.RefreshButton.Text = "Refresh";
            this.RefreshButton.Click += new System.EventHandler(this.RefreshButton_Click_1);
            // 
            // SaveButton
            // 
            this.SaveButton.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SaveButton.Location = new System.Drawing.Point(140, 19);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(125, 27);
            this.SaveButton.TabIndex = 39;
            this.SaveButton.Text = "Save Record";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeIDDataGridViewTextBoxColumn,
            this.empFirstNameDataGridViewTextBoxColumn,
            this.empLastNameDataGridViewTextBoxColumn,
            this.empEmailDataGridViewTextBoxColumn,
            this.empPhoneNoDataGridViewTextBoxColumn,
            this.empRoleDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.employeeBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(309, 44);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(540, 303);
            this.dataGridView1.TabIndex = 81;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            // 
            // empFirstNameDataGridViewTextBoxColumn
            // 
            this.empFirstNameDataGridViewTextBoxColumn.DataPropertyName = "Emp_FirstName";
            this.empFirstNameDataGridViewTextBoxColumn.HeaderText = "Emp_FirstName";
            this.empFirstNameDataGridViewTextBoxColumn.Name = "empFirstNameDataGridViewTextBoxColumn";
            // 
            // empLastNameDataGridViewTextBoxColumn
            // 
            this.empLastNameDataGridViewTextBoxColumn.DataPropertyName = "Emp_LastName";
            this.empLastNameDataGridViewTextBoxColumn.HeaderText = "Emp_LastName";
            this.empLastNameDataGridViewTextBoxColumn.Name = "empLastNameDataGridViewTextBoxColumn";
            // 
            // empEmailDataGridViewTextBoxColumn
            // 
            this.empEmailDataGridViewTextBoxColumn.DataPropertyName = "Emp_Email";
            this.empEmailDataGridViewTextBoxColumn.HeaderText = "Emp_Email";
            this.empEmailDataGridViewTextBoxColumn.Name = "empEmailDataGridViewTextBoxColumn";
            // 
            // empPhoneNoDataGridViewTextBoxColumn
            // 
            this.empPhoneNoDataGridViewTextBoxColumn.DataPropertyName = "Emp_PhoneNo";
            this.empPhoneNoDataGridViewTextBoxColumn.HeaderText = "Emp_PhoneNo";
            this.empPhoneNoDataGridViewTextBoxColumn.Name = "empPhoneNoDataGridViewTextBoxColumn";
            // 
            // empRoleDataGridViewTextBoxColumn
            // 
            this.empRoleDataGridViewTextBoxColumn.DataPropertyName = "Emp_Role";
            this.empRoleDataGridViewTextBoxColumn.HeaderText = "Emp_Role";
            this.empRoleDataGridViewTextBoxColumn.Name = "empRoleDataGridViewTextBoxColumn";
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.topGolfDataSet;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Homebutton);
            this.groupBox2.Controls.Add(this.ExitButton);
            this.groupBox2.Controls.Add(this.DeleteButton);
            this.groupBox2.Controls.Add(this.SaveButton);
            this.groupBox2.Controls.Add(this.AddNewButton);
            this.groupBox2.Location = new System.Drawing.Point(12, 225);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(284, 122);
            this.groupBox2.TabIndex = 80;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Commands::";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(employeeIDLabel);
            this.groupBox1.Controls.Add(this.employeeIDTextBox);
            this.groupBox1.Controls.Add(emp_FirstNameLabel);
            this.groupBox1.Controls.Add(this.emp_FirstNameTextBox);
            this.groupBox1.Controls.Add(emp_LastNameLabel);
            this.groupBox1.Controls.Add(this.emp_LastNameTextBox);
            this.groupBox1.Controls.Add(emp_EmailLabel);
            this.groupBox1.Controls.Add(this.emp_EmailTextBox);
            this.groupBox1.Controls.Add(emp_PhoneNoLabel);
            this.groupBox1.Controls.Add(this.emp_PhoneNoTextBox);
            this.groupBox1.Controls.Add(emp_RoleLabel);
            this.groupBox1.Controls.Add(this.emp_RoleTextBox);
            this.groupBox1.Location = new System.Drawing.Point(12, 44);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(284, 175);
            this.groupBox1.TabIndex = 79;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Info::";
            // 
            // employeeIDTextBox
            // 
            this.employeeIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "EmployeeID", true));
            this.employeeIDTextBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeIDTextBox.Location = new System.Drawing.Point(97, 16);
            this.employeeIDTextBox.Name = "employeeIDTextBox";
            this.employeeIDTextBox.Size = new System.Drawing.Size(100, 23);
            this.employeeIDTextBox.TabIndex = 1;
            // 
            // emp_FirstNameTextBox
            // 
            this.emp_FirstNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "Emp_FirstName", true));
            this.emp_FirstNameTextBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emp_FirstNameTextBox.Location = new System.Drawing.Point(97, 42);
            this.emp_FirstNameTextBox.Name = "emp_FirstNameTextBox";
            this.emp_FirstNameTextBox.Size = new System.Drawing.Size(100, 23);
            this.emp_FirstNameTextBox.TabIndex = 3;
            // 
            // emp_LastNameTextBox
            // 
            this.emp_LastNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "Emp_LastName", true));
            this.emp_LastNameTextBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emp_LastNameTextBox.Location = new System.Drawing.Point(97, 68);
            this.emp_LastNameTextBox.Name = "emp_LastNameTextBox";
            this.emp_LastNameTextBox.Size = new System.Drawing.Size(100, 23);
            this.emp_LastNameTextBox.TabIndex = 5;
            // 
            // emp_EmailTextBox
            // 
            this.emp_EmailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "Emp_Email", true));
            this.emp_EmailTextBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emp_EmailTextBox.Location = new System.Drawing.Point(97, 94);
            this.emp_EmailTextBox.Name = "emp_EmailTextBox";
            this.emp_EmailTextBox.Size = new System.Drawing.Size(100, 23);
            this.emp_EmailTextBox.TabIndex = 7;
            // 
            // emp_PhoneNoTextBox
            // 
            this.emp_PhoneNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "Emp_PhoneNo", true));
            this.emp_PhoneNoTextBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emp_PhoneNoTextBox.Location = new System.Drawing.Point(97, 120);
            this.emp_PhoneNoTextBox.Name = "emp_PhoneNoTextBox";
            this.emp_PhoneNoTextBox.Size = new System.Drawing.Size(100, 23);
            this.emp_PhoneNoTextBox.TabIndex = 9;
            // 
            // emp_RoleTextBox
            // 
            this.emp_RoleTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "Emp_Role", true));
            this.emp_RoleTextBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emp_RoleTextBox.Location = new System.Drawing.Point(97, 146);
            this.emp_RoleTextBox.Name = "emp_RoleTextBox";
            this.emp_RoleTextBox.Size = new System.Drawing.Size(100, 23);
            this.emp_RoleTextBox.TabIndex = 11;
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Customer_TrainingSessionsTableAdapter = null;
            this.tableAdapterManager.CustomerTableAdapter = this.customerTableAdapter;
            this.tableAdapterManager.EmployeeTableAdapter = null;
            this.tableAdapterManager.MembershipTableAdapter = null;
            this.tableAdapterManager.ReservationsTableAdapter = null;
            this.tableAdapterManager.TrainerTableAdapter = null;
            this.tableAdapterManager.TrainingProgramTableAdapter = null;
            this.tableAdapterManager.TrainingSessionTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = TopGolf.TopGolfDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VenueTableAdapter = null;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // FormEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(855, 391);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.CustomerBindingNavigator);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormEmployee_FormClosing);
            this.Load += new System.EventHandler(this.FormEmployee_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerBindingNavigator)).EndInit();
            this.CustomerBindingNavigator.ResumeLayout(false);
            this.CustomerBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.topGolfDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripButton BindingNavigatorSaveItem;
        private System.Windows.Forms.Button Homebutton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Button AddNewButton;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.BindingNavigator CustomerBindingNavigator;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private TopGolfDataSet topGolfDataSet;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton RefreshButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private TopGolfDataSetTableAdapters.CustomerTableAdapter customerTableAdapter;
        private TopGolfDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private TopGolfDataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empFirstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empLastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empEmailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empPhoneNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empRoleDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox employeeIDTextBox;
        private System.Windows.Forms.TextBox emp_FirstNameTextBox;
        private System.Windows.Forms.TextBox emp_LastNameTextBox;
        private System.Windows.Forms.TextBox emp_EmailTextBox;
        private System.Windows.Forms.TextBox emp_PhoneNoTextBox;
        private System.Windows.Forms.TextBox emp_RoleTextBox;
    }
}